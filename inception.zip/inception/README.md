# Inception

A small Docker Compose stack: NGINX (TLS termination) → WordPress + php-fpm → MariaDB,
all built from `alpine:3.23.5`, no pre-built service images.

## Before first run

1. **Change the placeholder passwords** in `secrets/*.txt` — they currently hold
   dummy values so the stack works out of the box, but treat them as
   compromised. Edit each file in place, no trailing newline needed.
2. Adjust `srcs/.env` if you want a different DB name, WP admin username, etc.
   (the WP admin username must not contain `admin`/`administrator` in any
   casing — `siteowner` is used by default).
3. The named volumes are pinned to `/home/me/data/mariadb` and
   `/home/me/data/wordpress` on the host, per the project spec. `make` creates
   those directories for you; adjust `DATA_DIR` in the `Makefile` if your
   login isn't `me`.

## Usage

```
make          # creates host dirs, adds domain to /etc/hosts, builds, starts
make down     # stop and remove containers
make clean    # down + prune dangling docker resources
make fclean   # clean + remove volumes and persisted data
make re       # fclean + all
```

Then visit `https://abdothma.42.fr` (self-signed cert — your browser will warn,
that's expected since there's no real CA involved).

## Layout

```
srcs/
  docker-compose.yml
  .env                        # non-secret config (domain, db name, usernames...)
  requirements/
    mariadb/    Dockerfile, conf/my.cnf, tools/init_db.sh
    wordpress/  Dockerfile, conf/www.conf, tools/wp_setup.sh
    nginx/      Dockerfile, conf/nginx.conf.template, tools/entrypoint.sh
secrets/                      # docker secrets, gitignored, passwords only
Makefile
```

## Notes on the requirements

- **Named volumes, no bind mounts**: both volumes use the `local` driver with
  `driver_opts` pointing at a fixed host path — Docker still manages them as
  named volumes (`docker volume ls`, lifecycle, etc.), it's just told where to
  physically store the data, satisfying the "must live under `/home/me/data`"
  constraint without a bind-mount entry in the service's `volumes:` list.
- **Two DB users**: `MYSQL_USER` (from `.env`) is the WordPress DB user with
  its password in `secrets/db_password.txt`; the `root` account's password is
  in `secrets/db_root_password.txt`. WordPress itself gets its own admin user
  (`WP_ADMIN_USER`) plus a second editor account (`WP_USER`), each with its
  own secret.
- **No passwords in any Dockerfile** — all four passwords only ever exist as
  files under `/run/secrets/...` inside the containers, sourced from
  `secrets/*.txt` via the `secrets:` block in `docker-compose.yml`.
